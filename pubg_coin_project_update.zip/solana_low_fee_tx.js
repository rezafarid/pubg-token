const {
  Connection,
  PublicKey,
  clusterApiUrl,
  Keypair,
  Transaction,
  SystemProgram,
  sendAndConfirmTransaction,
} = require("@solana/web3.js");

async function sendLowFeeTransaction(senderSecretKey, recipientPubKeyString, amountLamports) {
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  const senderKeypair = Keypair.fromSecretKey(Uint8Array.from(senderSecretKey));
  const recipientPubKey = new PublicKey(recipientPubKeyString);

  const transaction = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: senderKeypair.publicKey,
      toPubkey: recipientPubKey,
      lamports: amountLamports,
    })
  );

  const signature = await sendAndConfirmTransaction(connection, transaction, [senderKeypair]);
  console.log("Transaction successful with signature:", signature);
}

const senderSecretKey = [/* your private key array here */];
const recipientPubKeyString = "RecipientPublicKeyHere";
const amountLamports = 1000;

sendLowFeeTransaction(senderSecretKey, recipientPubKeyString, amountLamports);
